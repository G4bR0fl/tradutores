int main(int a, int b){
    float i;
    i = a;
    float* b;
}