int i;
i = 30;
int main(int a){
	return 0;
}
int i;
int j;