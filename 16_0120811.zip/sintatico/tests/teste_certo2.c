int main(int a){
    int i;
    i = 2;
    1+1;

    return 1;
}