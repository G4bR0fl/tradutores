int main() {
    int a;
    int b;
    a = 20;
    b = 2;
    if(b != 20) || ((a == NIL) && (a >= 2)){
        a *= 20;
    }
    else {
        c = 21.3;
    }
    read write writeln
    int list;
    return 0;
}