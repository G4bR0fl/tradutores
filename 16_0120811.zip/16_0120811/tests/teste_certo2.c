float modify_occurences(float i) {
	return i + 3.2;
}

float gt_n(float n) {
	int x;
	return x > n;
}

int main(int a){
    int i;
    i = 2;
    writeln("V3m c0m1G0 \t\r\\r//*\t*//m3u P4e\t//");
    int n;
	float list float_list;
	read(list_elements);
	float_list = list_elements : float_list;
	FL = modify_occurences >> float_list;
	float_list = gt_n <<  FL;
	if (float_list != NIL) {
		float list aux_list;
		int n; 
		n = 0;
		for (aux_list=float_list; aux_list != NIL; aux_list = !aux_list) {
			n = n + 1;
			write(%aux_list); write("\n"); write(?aux_list);
		}
	}
	writeln(" !?*@#//\t\r\x22C4rr1ag\x31r\%//*/."); writeln("\n");
    return 1;
}