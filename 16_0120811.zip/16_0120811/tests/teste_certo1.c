int bibibi;
lalala if else {()}; -1 asd_
asdas_
_dqwdqw
 if( ><> ==> >=<  , !!!  +-+ || *-*  && *=* % >> << for if }{ )    

  
