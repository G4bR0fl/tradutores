23be
1312_few#
int %$#@!read writeln 
