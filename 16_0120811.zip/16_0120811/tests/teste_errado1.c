int b;
b = 24.69.12